"use client";

import React, { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { BackendStatus } from "@/types";
import { Dot } from "./icons";
import { useTheme } from "@/hooks/useTheme";
import { useMagneticHover } from "@/hooks/useMagneticHover";

interface TopNavProps {
  status: BackendStatus;
  approvalsPending?: number;
}

const STATUS_META: Record<
  BackendStatus,
  { color: string; label: string; pulse: boolean }
> = {
  Connected: { color: "#22C55E", label: "Live", pulse: false },
  Connecting: { color: "#F59E0B", label: "Connecting", pulse: true },
  Disconnected: { color: "#EF4444", label: "Offline", pulse: true },
};

const NAV_LINKS: { href: string; label: string }[] = [
  { href: "/", label: "Home" },
  { href: "/playground", label: "Agent Playground" },
  { href: "/security-testing", label: "Security Testing" },
  { href: "/audit-logs", label: "Audit Logs" },
  { href: "/evaluation", label: "Evaluation" },
];

const SearchIcon: React.FC<{ size?: number }> = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="7" />
    <line x1="21" y1="21" x2="16.5" y2="16.5" />
  </svg>
);

const RefreshIcon: React.FC<{ size?: number }> = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 12a9 9 0 0 1 15-6.7L21 8" />
    <polyline points="21 3 21 8 16 8" />
    <path d="M21 12a9 9 0 0 1-15 6.7L3 16" />
    <polyline points="3 21 3 16 8 16" />
  </svg>
);

const BellIcon: React.FC<{ size?: number }> = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.7 21a2 2 0 0 1-3.4 0" />
  </svg>
);

const ShieldCheckIcon: React.FC<{ size?: number }> = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3l8 3v6c0 5-3.4 8.4-8 10-4.6-1.6-8-5-8-10V6l8-3z" />
    <polyline points="9 12 11 14 15 10" />
  </svg>
);

const SunIcon: React.FC<{ size?: number }> = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
  </svg>
);

const MoonIcon: React.FC<{ size?: number }> = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
  </svg>
);

/** Magnetic nav link wrapper */
const NavLink: React.FC<{ href: string; label: string; active: boolean }> = ({
  href,
  label,
  active,
}) => {
  const ref = useMagneticHover<HTMLAnchorElement>(0.25);
  return (
    <Link
      ref={ref}
      href={href}
      className={`rounded-md px-3 py-1.5 text-[13px] font-semibold transition-all duration-200 ${
        active
          ? "text-white"
          : "text-slate-400 hover:text-white"
      }`}
      style={
        active
          ? {
              background:
                "linear-gradient(135deg, rgba(255, 106, 0, 0.18), rgba(255, 194, 26, 0.12))",
              boxShadow:
                "inset 0 1px 0 0 rgba(255, 255, 255, 0.06), 0 0 0 1px rgba(255, 106, 0, 0.35), 0 0 12px -2px rgba(255, 106, 0, 0.25)",
            }
          : undefined
      }
    >
      {label}
    </Link>
  );
};

const TopNav: React.FC<TopNavProps> = ({ status, approvalsPending = 0 }) => {
  const m = STATUS_META[status];
  const [search, setSearch] = useState("");
  const pathname = usePathname();
  const { toggle } = useTheme();

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  // Mouse-tracking glow
  const navRef = useRef<HTMLElement>(null);
  const [glow, setGlow] = useState<{ x: number; y: number; visible: boolean }>({
    x: 0,
    y: 0,
    visible: false,
  });

  useEffect(() => {
    const nav = navRef.current;
    if (!nav) return;
    const onMove = (e: MouseEvent) => {
      const rect = nav.getBoundingClientRect();
      setGlow({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        visible: true,
      });
    };
    const onLeave = () => setGlow((g) => ({ ...g, visible: false }));
    nav.addEventListener("mousemove", onMove);
    nav.addEventListener("mouseleave", onLeave);
    return () => {
      nav.removeEventListener("mousemove", onMove);
      nav.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  return (
    <nav
      ref={navRef}
      className="sticky top-3 z-30 mb-6 rounded-2xl border border-ink-600 bg-ink-900/80 px-4 py-3 backdrop-blur-xl md:px-5"
      style={{
        boxShadow:
          "inset 0 1px 0 0 rgba(255, 255, 255, 0.05), 0 8px 32px -8px rgba(0, 0, 0, 0.60), 0 2px 8px -2px rgba(255, 106, 0, 0.10)",
        transition: "box-shadow 300ms ease",
      }}
    >
      {/* Mouse-tracking radial glow (JS effect) */}
      <div
        className="pointer-events-none absolute inset-0 rounded-2xl transition-opacity duration-300"
        style={{
          opacity: glow.visible ? 1 : 0,
          background: `radial-gradient(280px 80px at ${glow.x}px ${glow.y}px, rgba(255, 106, 0, 0.12), transparent 70%)`,
        }}
      />

      <div className="relative flex items-center gap-4 md:gap-6">
        {/* Left: logo + nav links */}
        <div className="flex items-center gap-5 md:gap-7">
          <Link
            href="/"
            className="flex items-center gap-3 transition-transform hover:scale-[1.02]"
          >
            <Image
              src="/brand-m.png"
              alt="PROMPTWALL"
              width={56}
              height={28}
              className="h-7 w-auto logo-image"
              priority
            />
            <span className="hidden text-base font-extrabold tracking-tight text-white sm:inline">
              PROMPT<span className="text-gradient-warm">WALL</span>
            </span>
          </Link>

          <span className="hidden h-6 w-px bg-ink-600 md:inline-block" />

          {/* Nav links — magnetic hover */}
          <div className="hidden items-center gap-1 lg:flex">
            {NAV_LINKS.map((link) => (
              <NavLink
                key={link.href}
                href={link.href}
                label={link.label}
                active={isActive(link.href)}
              />
            ))}
          </div>
        </div>

        {/* Right: theme toggle + approvals + status + search + actions */}
        <div className="ml-auto flex items-center gap-2 md:gap-3">
          {/* Theme toggle — both icons rendered, CSS controls visibility */}
          <button
            type="button"
            onClick={toggle}
            title="Toggle light / dark theme"
            className="relative flex h-8 w-8 items-center justify-center rounded-lg border border-ink-600 bg-ink-850 text-slate-400 transition-all hover:-translate-y-0.5 hover:border-accent-blue/40 hover:text-accent-blue"
            style={{ boxShadow: "var(--shadow-3d-sm)" }}
          >
            <span className="theme-icon-dark">
              <SunIcon size={15} />
            </span>
            <span className="theme-icon-light">
              <MoonIcon size={15} />
            </span>
          </button>

          {/* Approvals badge */}
          <Link
            href="/approvals"
            className={`hidden items-center gap-1.5 rounded-md border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider transition-all sm:inline-flex ${
              approvalsPending > 0
                ? "border-status-warn/40 bg-status-warn/10 text-status-warn hover:bg-status-warn/20"
                : "border-ink-600 bg-ink-850 text-slate-400 hover:text-white"
            }`}
            style={{ boxShadow: "var(--shadow-3d-sm)" }}
            title="Human approval queue"
          >
            <ShieldCheckIcon size={13} />
            Approvals
            {approvalsPending > 0 && (
              <span className="ml-0.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-status-warn px-1 text-[10px] font-bold text-black">
                {approvalsPending}
              </span>
            )}
          </Link>

          <span
            className="chip hidden border border-ink-600 bg-ink-850 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider sm:inline-flex"
            style={{ color: m.color }}
          >
            <Dot color={m.color} pulse={m.pulse} />
            {m.label}
          </span>

          <div className="relative hidden xl:block">
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
              <SearchIcon size={15} />
            </span>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search events, policies, agents…"
              className="input-base w-44 rounded-lg py-1.5 pl-9 pr-12 text-[12.5px] md:w-56"
            />
            <kbd className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 rounded border border-ink-600 bg-ink-850 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-slate-500">
              ⌘K
            </kbd>
          </div>

          <button
            type="button"
            title="Refresh"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-ink-600 bg-ink-850 text-slate-400 transition-all hover:-translate-y-0.5 hover:border-accent-blue/40 hover:text-accent-blue"
            style={{ boxShadow: "var(--shadow-3d-sm)" }}
          >
            <RefreshIcon size={15} />
          </button>

          <button
            type="button"
            title="Notifications"
            className="relative flex h-8 w-8 items-center justify-center rounded-lg border border-ink-600 bg-ink-850 text-slate-400 transition-all hover:-translate-y-0.5 hover:border-accent-blue/40 hover:text-accent-blue"
            style={{ boxShadow: "var(--shadow-3d-sm)" }}
          >
            <BellIcon size={15} />
            <span
              className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-accent-blue"
              style={{ boxShadow: "0 0 6px rgba(255, 106, 0, 0.7)" }}
            />
          </button>

          <div
            className="flex h-8 w-8 items-center justify-center rounded-full text-[11px] font-bold text-black"
            style={{
              backgroundImage: "linear-gradient(135deg, #FF6A00, #FFC21A)",
              boxShadow: "var(--shadow-3d-sm)",
            }}
            title="Signed in as Operator"
          >
            OP
          </div>
        </div>
      </div>
    </nav>
  );
};

export default TopNav;
