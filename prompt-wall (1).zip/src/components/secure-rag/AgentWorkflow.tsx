"use client";

import React from "react";
import type { StageId, StageStatus, WorkflowStage } from "@/types";
import {
  UserIcon,
  SearchIcon,
  FirewallIcon,
  CpuIcon,
  LockIcon,
  ToolIcon,
  DocIcon,
  SpinnerIcon,
  CheckIcon,
  ClockIcon,
  XIcon,
  AlertTriangleIcon,
} from "./icons";

interface AgentWorkflowProps {
  stages: WorkflowStage[];
}

const STAGE_ICONS: Record<StageId, React.FC<{ size?: number }>> = {
  user_request: UserIcon,
  scope_extraction: SearchIcon,
  rag_retrieval: SearchIcon,
  content_firewall: FirewallIcon,
  agent: CpuIcon,
  action_guard: LockIcon,
  tool_execution: ToolIcon,
  final_response: DocIcon,
};

const STATUS_META: Record<
  StageStatus,
  {
    color: string;
    ring: string;
    bg: string;
    text: string;
    icon: React.FC<{ size?: number }>;
    label: string;
  }
> = {
  Pending: {
    color: "#A1A1A1",
    ring: "border-ink-600",
    bg: "bg-ink-850",
    text: "text-slate-400",
    icon: ClockIcon,
    label: "Pending",
  },
  Running: {
    color: "#FF6A00",
    ring: "border-accent-blue",
    bg: "bg-accent-blue/10",
    text: "text-accent-blue-bright",
    icon: SpinnerIcon,
    label: "Running",
  },
  Passed: {
    color: "#22C55E",
    ring: "border-status-allow/50",
    bg: "bg-status-allow/10",
    text: "text-status-allow",
    icon: CheckIcon,
    label: "Passed",
  },
  Blocked: {
    color: "#EF4444",
    ring: "border-status-block/50",
    bg: "bg-status-block/10",
    text: "text-status-block",
    icon: XIcon,
    label: "Blocked",
  },
  Warning: {
    color: "#F59E0B",
    ring: "border-status-warn/50",
    bg: "bg-status-warn/10",
    text: "text-status-warn",
    icon: AlertTriangleIcon,
    label: "Threat",
  },
  Failed: {
    color: "#EF4444",
    ring: "border-status-block/50",
    bg: "bg-status-block/10",
    text: "text-status-block",
    icon: XIcon,
    label: "Failed",
  },
  "Waiting for Approval": {
    color: "#F59E0B",
    ring: "border-status-warn/50",
    bg: "bg-status-warn/10",
    text: "text-status-warn",
    icon: AlertTriangleIcon,
    label: "Waiting",
  },
};

const AgentWorkflow: React.FC<AgentWorkflowProps> = ({ stages }) => {
  const activeStage = stages.find(
    (s) => s.status === "Running" || s.status === "Waiting for Approval"
  );

  return (
    <section className="card card-pad h-full">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="section-title">Agent Workflow</h2>
        <span className="tabular-nums text-[11px] text-slate-500">
          {stages.filter((s) => s.status === "Passed").length}/{stages.length} passed
          {activeStage && (
            <span className="ml-2 text-accent-blue-bright">
              · active: {activeStage.label}
            </span>
          )}
        </span>
      </div>

      {/* Responsive grid — never clips horizontally.
          2 cols on mobile, 4 on tablet, 8 on desktop (all stages in one row). */}
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4 lg:grid-cols-8">
        {stages.map((stage, idx) => (
          <StageCard
            key={stage.id}
            stage={stage}
            index={idx + 1}
            isActive={stage.id === activeStage?.id}
          />
        ))}
      </div>
    </section>
  );
};

const StageCard: React.FC<{
  stage: WorkflowStage;
  index: number;
  isActive: boolean;
}> = ({ stage, index, isActive }) => {
  const Icon = STAGE_ICONS[stage.id];
  const meta = STATUS_META[stage.status];
  const StatusIcon = meta.icon;

  // Active stage gets a stronger 3D treatment + animated ring
  const activeClasses = isActive
    ? "ring-2 ring-accent-blue/60 scale-[1.03] z-10"
    : "";

  const activeShadow =
    stage.status === "Running"
      ? "var(--shadow-3d-lg)"
      : stage.status === "Waiting for Approval"
      ? "var(--shadow-glow-yellow)"
      : stage.status === "Blocked"
      ? "var(--shadow-glow-red)"
      : stage.status === "Passed"
      ? "var(--shadow-3d-md)"
      : "var(--shadow-3d-sm)";

  return (
    <div
      className={`hover-lift relative flex flex-col items-center gap-2 rounded-xl border ${meta.ring} ${meta.bg} p-3 text-center ${activeClasses} animate-fade-in-up`}
      style={{
        boxShadow: activeShadow,
        transition: "transform 250ms cubic-bezier(0.16, 1, 0.3, 1), box-shadow 250ms cubic-bezier(0.16, 1, 0.3, 1)",
      }}
    >
      {/* Stage number badge */}
      <span
        className="absolute left-2 top-2 flex h-5 w-5 items-center justify-center rounded-full bg-ink-800 font-mono text-[10px] font-bold text-slate-400"
        style={{ boxShadow: "var(--shadow-3d-sm)" }}
      >
        {index}
      </span>

      {/* Active pulsing dot (top-right) */}
      {isActive && (
        <span
          className="absolute right-2 top-2 h-2 w-2 rounded-full animate-pulse-soft"
          style={{ background: meta.color, boxShadow: `0 0 8px ${meta.color}` }}
        />
      )}

      {/* Stage icon */}
      <div
        className={`mt-3 flex h-9 w-9 items-center justify-center rounded-lg ${meta.bg} ${meta.text} ${
          stage.status === "Running" ? "animate-pulse-soft" : ""
        }`}
        style={{ boxShadow: "inset 0 1px 0 0 rgba(255,255,255,0.04)" }}
      >
        <Icon size={18} />
      </div>

      {/* Label */}
      <div className="text-[13px] font-semibold leading-tight text-white">
        {stage.label}
      </div>

      {/* Status chip */}
      <div
        className="chip border border-ink-600 bg-ink-850 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider"
        style={{ color: meta.color }}
      >
        <StatusIcon size={11} />
        {meta.label}
      </div>

      {stage.result && (
        <div className="text-[10px] leading-snug text-slate-400 line-clamp-2">
          {stage.result}
        </div>
      )}
      {stage.durationMs !== undefined && stage.durationMs > 0 && (
        <div className="text-[9px] font-mono tabular-nums text-slate-600">
          {stage.durationMs}ms
        </div>
      )}
    </div>
  );
};

export default AgentWorkflow;
