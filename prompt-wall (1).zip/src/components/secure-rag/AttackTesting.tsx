"use client";

import React, { useMemo, useState } from "react";
import type {
  AttackCategory,
  AttackDef,
  AttackResult,
  AttackRunResult,
} from "@/types";
import {
  ATTACK_CATEGORIES,
  ATTACK_LIBRARY,
  attacksForCategory,
} from "@/lib/secure-rag/mockData";
import {
  FlaskIcon,
  CheckIcon,
  XIcon,
  SpinnerIcon,
} from "./icons";

interface AttackTestingProps {
  result: AttackRunResult | null;
  running: boolean;
  onRun: (attack: AttackDef) => void;
}

const RESULT_META: Record<
  AttackResult,
  { label: string; color: string; icon: React.FC<{ size?: number }> }
> = {
  BLOCKED: { label: "BLOCKED", color: "#22C55E", icon: CheckIcon },
  BYPASSED: { label: "BYPASSED", color: "#EF4444", icon: XIcon },
  PENDING: { label: "PENDING", color: "#A1A1A1", icon: SpinnerIcon },
};

const AttackTesting: React.FC<AttackTestingProps> = ({
  result,
  running,
  onRun,
}) => {
  const [category, setCategory] = useState<AttackCategory>(ATTACK_CATEGORIES[0]);
  const [attackId, setAttackId] = useState<string>(
    attacksForCategory(ATTACK_CATEGORIES[0])[0].id
  );

  const attacks = useMemo(() => attacksForCategory(category), [category]);

  const selectedAttack = useMemo(
    () => ATTACK_LIBRARY.find((a) => a.id === attackId) ?? attacks[0],
    [attackId, attacks]
  );

  const onChangeCategory = (cat: AttackCategory) => {
    setCategory(cat);
    const first = attacksForCategory(cat)[0];
    setAttackId(first.id);
  };

  const meta = result ? RESULT_META[result.result] : null;
  const ResultIcon = meta?.icon;

  return (
    <section className="card card-pad h-full">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="section-title">Attack Testing</h2>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <div>
          <label className="mb-1 block text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
            Attack category
          </label>
          <select
            className="input-base"
            value={category}
            onChange={(e) => onChangeCategory(e.target.value as AttackCategory)}
            disabled={running}
          >
            {ATTACK_CATEGORIES.map((c) => (
              <option key={c} value={c} className="bg-ink-900 text-white">
                {c}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1 block text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
            Attack
          </label>
          <select
            className="input-base"
            value={attackId}
            onChange={(e) => setAttackId(e.target.value)}
            disabled={running}
          >
            {attacks.map((a) => (
              <option key={a.id} value={a.id} className="bg-ink-900 text-white">
                {a.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Payload preview */}
      <div className="mt-3">
        <div className="mb-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
          Payload preview
        </div>
        <pre className="surface-sunken max-h-32 overflow-auto p-3 font-mono text-[12px] leading-snug text-slate-300">
{selectedAttack?.payload ?? ""}
        </pre>
      </div>

      {/* Run button + result */}
      <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <button
          type="button"
          className="btn btn-primary shadow-glow-purple"
          onClick={() => selectedAttack && onRun(selectedAttack)}
          disabled={running || !selectedAttack}
        >
          {running ? <SpinnerIcon size={16} /> : <FlaskIcon size={16} />}
          {running ? "Running Attack…" : "Run Attack"}
        </button>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
            Result
          </span>
          {meta && ResultIcon ? (
            <div
              className="chip hover-lift border px-3 py-1 font-semibold"
              style={{
                color: meta.color,
                borderColor: `${meta.color}55`,
                background: `${meta.color}11`,
                boxShadow: `var(--shadow-3d-sm), 0 0 0 1px ${meta.color}30`,
              }}
            >
              <ResultIcon size={13} />
              {meta.label}
            </div>
          ) : (
            <span className="chip border border-ink-600 bg-ink-850 text-slate-500" style={{ boxShadow: "var(--shadow-3d-sm)" }}>
              —
            </span>
          )}
        </div>
      </div>

      {result?.detail && (
        <div className="surface-sunken mt-3 p-3 text-[12.5px] text-slate-400">
          {result.detail}
        </div>
      )}
    </section>
  );
};

export default AttackTesting;
