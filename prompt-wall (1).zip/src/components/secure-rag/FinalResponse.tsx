"use client";

import React from "react";
import type { FinalResponse } from "@/types";
import { DocIcon, CheckIcon } from "./icons";

interface FinalResponsePanelProps {
  response: FinalResponse | null;
  onRunAgain?: () => void;
}

const FinalResponsePanel: React.FC<FinalResponsePanelProps> = ({
  response,
  onRunAgain,
}) => {
  const empty = !response || !response.ready;

  return (
    <section className="card card-pad h-full">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="section-title">Final Response</h2>
        <span className="text-[11px] text-slate-500">
          {empty ? "awaiting" : "delivered"}
        </span>
      </div>

      {empty ? (
        <div className="surface-sunken flex items-center gap-3 p-4 text-sm text-slate-400">
          <DocIcon size={18} />
          The agent&apos;s response will appear here once the pipeline completes.
        </div>
      ) : (
        <div className="space-y-4">
          {/* Status banner */}
          <div
            className="hover-lift rounded-xl border border-status-allow/25 bg-status-allow/[0.06] p-4"
            style={{ boxShadow: "var(--shadow-glow-green)" }}
          >
            <div className="flex items-center gap-2">
              <CheckIcon size={18} className="text-status-allow" />
              <span className="text-sm font-bold uppercase tracking-wide text-status-allow">
                Task Completed Safely
              </span>
            </div>
            <p className="mt-2 text-[14px] leading-relaxed text-slate-200">
              {response!.text}
            </p>
          </div>

          {/* Vendor comparison (demo scenario) */}
          {response!.vendors && response!.vendors.length > 0 && (
            <div className="surface-sunken p-4">
              <div className="mb-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
                Vendor comparison
              </div>
              <div className="space-y-2">
                {response!.vendors.map((v) => (
                  <div
                    key={v.name}
                    className={`flex items-center justify-between rounded-lg border px-3 py-2 ${
                      v.isLowest
                        ? "border-status-allow/40 bg-status-allow/10"
                        : "border-ink-600 bg-ink-900"
                    }`}
                  >
                    <span className="text-[13px] font-medium text-slate-200">
                      {v.name}
                    </span>
                    <span
                      className={`tabular-nums font-mono text-[13px] ${
                        v.isLowest ? "text-status-allow font-bold" : "text-slate-400"
                      }`}
                    >
                      {v.price}
                    </span>
                  </div>
                ))}
              </div>
              {response!.result && (
                <div className="mt-3 text-[13px] text-slate-300">
                  <span className="text-slate-500">Result: </span>
                  {response!.result}
                </div>
              )}
            </div>
          )}

          {/* Security summary */}
          {response!.securitySummary && response!.securitySummary.length > 0 && (
            <div className="surface-sunken p-4">
              <div className="mb-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
                Security
              </div>
              <ul className="space-y-1.5">
                {response!.securitySummary.map((s, i) => (
                  <li key={i} className="flex items-center gap-2 text-[13px] text-slate-300">
                    <CheckIcon size={14} className="text-status-allow shrink-0" />
                    {s}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              className="btn-ghost btn border border-ink-600 bg-ink-800 text-slate-300"
            >
              View Audit
            </button>
            {onRunAgain && (
              <button
                type="button"
                onClick={onRunAgain}
                className="btn btn-primary"
              >
                Run Again
              </button>
            )}
          </div>
        </div>
      )}
    </section>
  );
};

export default FinalResponsePanel;
