"use client";

import React from "react";
import type { SecurityDecision } from "@/types";
import { CheckIcon, XIcon, AlertTriangleIcon, LockIcon } from "./icons";

interface SecurityDecisionProps {
  decision: SecurityDecision | null;
  onApprove: () => void;
  onReject: () => void;
  resolving?: boolean;
}

const DECISION_META = {
  ALLOW: {
    label: "ALLOW",
    color: "#22C55E",
    ring: "border-status-allow/40",
    bg: "from-status-allow/15",
    icon: CheckIcon,
    summary: "Request cleared all guardrails and is executing within scope.",
  },
  BLOCK: {
    label: "BLOCK",
    color: "#EF4444",
    ring: "border-status-block/40",
    bg: "from-status-block/15",
    icon: XIcon,
    summary: "A threat was detected. Request terminated.",
  },
  ASK_HUMAN: {
    label: "ASK HUMAN",
    color: "#F59E0B",
    ring: "border-status-warn/40",
    bg: "from-status-warn/15",
    icon: AlertTriangleIcon,
    summary: "Sensitive action proposed — human confirmation required.",
  },
} as const;

const SecurityDecisionPanel: React.FC<SecurityDecisionProps> = ({
  decision,
  onApprove,
  onReject,
  resolving,
}) => {
  if (!decision) {
    return (
      <section className="card card-pad h-full">
        <h2 className="section-title mb-4">Security Decision</h2>
        <div className="surface-sunken flex items-center gap-3 p-4 text-slate-400">
          <LockIcon size={18} />
          <span className="text-sm">
            No active decision. Submit a request to see the security verdict.
          </span>
        </div>
      </section>
    );
  }

  const meta = DECISION_META[decision.type];
  const Icon = meta.icon;

  return (
    <section className="card card-pad h-full">
      <h2 className="section-title mb-4">Security Decision</h2>

      <div className={`rounded-xl border ${meta.ring} bg-gradient-to-br ${meta.bg} to-transparent p-4 hover-lift`} style={{ boxShadow: "var(--shadow-3d-lg)" }}>
        <div className="flex items-center gap-3">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-lg border"
            style={{
              borderColor: meta.color,
              color: meta.color,
              background: `${meta.color}14`,
              boxShadow: `inset 0 1px 0 0 rgba(255,255,255,0.5), 0 4px 10px -2px ${meta.color}55`,
            }}
          >
            <Icon size={20} />
          </div>
          <div>
            <div
              className="text-lg font-extrabold tracking-wide"
              style={{ color: meta.color, textShadow: `0 1px 0 rgba(255,255,255,0.6)` }}
            >
              {meta.label}
            </div>
            <div className="text-xs text-slate-400">{meta.summary}</div>
          </div>
        </div>

        {/* Block details */}
        {decision.type === "BLOCK" && decision.block && (
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <Field label="Threat type" value={decision.block.threatType} accent="#EF4444" />
            <Field label="Proposed action" value={decision.block.proposedTool} mono />
            {decision.block.risk && (
              <Field label="Risk" value={decision.block.risk} />
            )}
            {decision.block.policy && (
              <Field label="Policy" value={decision.block.policy} mono />
            )}
            <div className="sm:col-span-2">
              <Field
                label="Evidence (triggering content)"
                value={decision.block.triggeringContent}
                mono
                block
                quote
                italic
              />
            </div>
            {decision.block.evidence && (
              <Field label="Evidence flow" value={decision.block.evidence} mono />
            )}
            {decision.block.detectionLayer && (
              <Field label="Detection layer" value={decision.block.detectionLayer} />
            )}
            <div className="sm:col-span-2">
              <Field label="Reason" value={decision.block.reason} block />
            </div>
            {decision.block.confidence !== undefined && (
              <div className="sm:col-span-2 surface-sunken p-3">
                <div className="mb-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-500">
                  Confidence
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-2 w-full overflow-hidden rounded-full bg-ink-700">
                    <div
                      className="h-full"
                      style={{
                        width: `${decision.block.confidence}%`,
                        background: "linear-gradient(90deg, #FF6A00, #FFC21A)",
                      }}
                    />
                  </div>
                  <span className="tabular-nums text-sm font-bold text-accent-blue-bright">
                    {decision.block.confidence}%
                  </span>
                </div>
              </div>
            )}
            <div className="sm:col-span-2 flex gap-2">
              <button className="btn-ghost btn border border-ink-600 bg-ink-800 text-slate-300">
                View Full Audit Event
              </button>
            </div>
          </div>
        )}

        {/* Ask-human details */}
        {decision.type === "ASK_HUMAN" && decision.askHuman && (
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <Field label="Proposed action" value={decision.askHuman.proposedAction} mono />
            <div className="sm:col-span-2">
              <Field label="Reason" value={decision.askHuman.reason} block />
            </div>
            <div className="sm:col-span-2 flex flex-wrap gap-2 pt-1">
              <button
                className="btn btn-success"
                onClick={onApprove}
                disabled={resolving}
              >
                <CheckIcon size={16} />
                Approve
              </button>
              <button
                className="btn btn-danger"
                onClick={onReject}
                disabled={resolving}
              >
                <XIcon size={16} />
                Reject
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

const Field: React.FC<{
  label: string;
  value: string;
  mono?: boolean;
  block?: boolean;
  quote?: boolean;
  italic?: boolean;
  accent?: string;
}> = ({ label, value, mono, block, quote, italic, accent }) => (
  <div
    className={`surface-sunken p-3 ${block ? "w-full" : ""}`}
  >
    <div className="mb-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-500">
      {label}
    </div>
    <div
      className={`text-sm leading-snug text-slate-100 ${mono ? "font-mono text-[12.5px]" : ""} ${
        italic ? "italic text-slate-300" : ""
      } ${quote ? "border-l-2 pl-2" : ""}`}
      style={quote && accent ? { borderColor: accent } : quote ? { borderColor: "#FF6A00" } : undefined}
    >
      {value}
    </div>
  </div>
);

export default SecurityDecisionPanel;
