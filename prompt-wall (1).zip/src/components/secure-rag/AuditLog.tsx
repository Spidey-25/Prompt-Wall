"use client";

import React, { useMemo } from "react";
import type { AuditEvent, AuditStatus } from "@/types";
import { ClockIcon } from "./icons";

interface AuditLogProps {
  events: AuditEvent[];
}

const STATUS_DOT: Record<AuditStatus, string> = {
  info: "#FF6A00",
  success: "#22C55E",
  warning: "#F59E0B",
  danger: "#EF4444",
};

const STATUS_TEXT: Record<AuditStatus, string> = {
  info: "text-accent-blue-bright",
  success: "text-status-allow",
  warning: "text-status-warn",
  danger: "text-status-block",
};

function fmtTime(iso: string): string {
  const d = new Date(iso);
  const hh = d.getHours().toString().padStart(2, "0");
  const mm = d.getMinutes().toString().padStart(2, "0");
  const ss = d.getSeconds().toString().padStart(2, "0");
  const ms = d.getMilliseconds().toString().padStart(3, "0").slice(0, 3);
  return `${hh}:${mm}:${ss}.${ms}`;
}

const AuditLog: React.FC<AuditLogProps> = ({ events }) => {
  const sorted = useMemo(
    () =>
      [...events].sort(
        (a, b) => +new Date(b.timestamp) - +new Date(a.timestamp)
      ),
    [events]
  );

  return (
    <section className="card card-pad h-full">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="section-title">Live Audit Log</h2>
        <span className="tabular-nums text-[11px] text-slate-500">{events.length} events</span>
      </div>

      {sorted.length === 0 ? (
        <div className="surface-sunken flex items-center gap-2 p-3 text-sm text-slate-400">
          <ClockIcon size={16} />
          No events yet. Events will appear here in real time.
        </div>
      ) : (
        <ol className="relative max-h-[420px] space-y-1.5 overflow-y-auto pr-1">
          {sorted.map((ev) => (
            <li
              key={ev.id}
              className="hover-lift flex items-start gap-3 rounded-lg border border-ink-600 bg-ink-850 px-3 py-2.5 animate-fade-in-up"
              style={{ boxShadow: "var(--shadow-3d-sm)" }}
            >
              <span
                className="mt-1.5 inline-block h-2 w-2 shrink-0 rounded-full"
                style={{
                  background: STATUS_DOT[ev.status],
                  boxShadow: `0 0 8px ${STATUS_DOT[ev.status]}`,
                }}
              />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="tabular-nums font-mono text-[11px] text-slate-500">
                    {fmtTime(ev.timestamp)}
                  </span>
                  <span
                    className={`chip border border-ink-600 bg-ink-900 px-1.5 py-0 font-mono text-[10px] font-semibold ${STATUS_TEXT[ev.status]}`}
                    style={{ boxShadow: "var(--shadow-3d-sm)" }}
                  >
                    {ev.eventType}
                  </span>
                </div>
                <div className="mt-0.5 text-[13px] leading-snug text-slate-300">
                  {ev.description}
                </div>
              </div>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
};

export default AuditLog;
