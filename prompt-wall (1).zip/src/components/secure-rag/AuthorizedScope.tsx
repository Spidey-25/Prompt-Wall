"use client";

import React from "react";
import type { Scope } from "@/types";
import { DEMO_SCOPE } from "@/lib/secure-rag/mockData";

interface AuthorizedScopeProps {
  scope?: Scope;
  onExpand?: () => void;
}

/**
 * Authorized Scope — compact panel showing the goal, allowed/restricted tools,
 * resources, and external recipients extracted from the user's request.
 * This is the PS-required scope extraction preview.
 */
const AuthorizedScope: React.FC<AuthorizedScopeProps> = ({
  scope = DEMO_SCOPE,
  onExpand,
}) => {
  return (
    <section className="card card-pad h-full">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="section-title">Authorized Scope</h2>
        <button
          type="button"
          onClick={onExpand}
          className="btn-ghost rounded-md border border-ink-600 bg-ink-800 px-2.5 py-1 text-[11px] font-semibold text-slate-300 hover:border-accent-blue/40 hover:text-white"
          style={{ boxShadow: "var(--shadow-3d-sm)" }}
        >
          Expand Scope
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Goal" value={scope.goal} block />
        <div className="sm:col-span-2 grid gap-3 sm:grid-cols-2">
          <div>
            <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-500">
              Allowed Tools
            </div>
            <div className="flex flex-wrap gap-1.5">
              {scope.allowedTools.map((t) => (
                <span
                  key={t}
                  className="chip border border-status-allow/30 bg-status-allow/10 text-[11px] font-mono text-status-allow"
                >
                  ✓ {t}
                </span>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-500">
              Restricted Tools
            </div>
            <div className="flex flex-wrap gap-1.5">
              {scope.restrictedTools.map((t) => (
                <span
                  key={t}
                  className="chip border border-status-block/30 bg-status-block/10 text-[11px] font-mono text-status-block"
                >
                  🔒 {t}
                </span>
              ))}
            </div>
          </div>
        </div>
        <Field label="Allowed Resources" value={scope.allowedResources} mono />
        <Field label="External Recipients" value={scope.externalRecipients} mono />
      </div>
    </section>
  );
};

const Field: React.FC<{
  label: string;
  value: string;
  mono?: boolean;
  block?: boolean;
}> = ({ label, value, mono, block }) => (
  <div className={`surface-sunken p-3 ${block ? "sm:col-span-2" : ""}`}>
    <div className="mb-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-500">
      {label}
    </div>
    <div
      className={`text-[13px] leading-snug text-slate-200 ${
        mono ? "font-mono text-[12px]" : ""
      }`}
    >
      {value}
    </div>
  </div>
);

export default AuthorizedScope;
