"use client";

import React from "react";
import Image from "next/image";
import type { BackendStatus } from "@/types";
import TopNav from "./TopNav";

interface PageShellProps {
  children: React.ReactNode;
  status?: BackendStatus;
  /** Hide the faint corner watermark (default false). */
  hideWatermark?: boolean;
}

/**
 * PageShell — shared page wrapper for every route.
 * Renders the sticky TopNav + a faint logo watermark + the page content.
 * Wide container (max-w-[1600px]) with generous padding so pages feel
 * like a real enterprise security platform, not a tiny centered card.
 */
const PageShell: React.FC<PageShellProps> = ({
  children,
  status = "Connected",
  hideWatermark = false,
}) => {
  return (
    <main className="relative min-h-screen w-full px-5 py-5 md:px-8 md:py-7 lg:px-10">
      {!hideWatermark && (
        <Image
          src="/brand-m.png"
          alt=""
          width={360}
          height={360}
          aria-hidden
          className="logo-watermark"
        />
      )}
      <div className="relative mx-auto w-full max-w-[1600px]">
        <TopNav status={status} />
        {children}
      </div>
    </main>
  );
};

export default PageShell;
