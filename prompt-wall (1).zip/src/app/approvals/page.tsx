"use client";

import React, { useState } from "react";
import PageShell from "@/components/secure-rag/PageShell";
import Reveal from "@/components/secure-rag/Reveal";
import { CheckIcon, XIcon } from "@/components/secure-rag/icons";

/**
 * Approvals — human-in-the-loop action queue.
 * Each pending item shows: Proposed action, Tool, Resource, Recipient,
 * Reason, and Approve / Reject controls.
 */
interface ApprovalItem {
  id: string;
  timestamp: string;
  proposedAction: string;
  tool: string;
  resource: string;
  recipient: string;
  reason: string;
}

const SEED_APPROVALS: ApprovalItem[] = [
  {
    id: "apr-001",
    timestamp: new Date(Date.now() - 1000 * 60 * 2).toISOString(),
    proposedAction: "Send summary email to external address",
    tool: "email.send",
    resource: "user_report_q3.pdf",
    recipient: "analyst@external-vendor.com",
    reason:
      "Out-of-scope recipient. The destination domain is not in the allow-list. Human confirmation required before transmission.",
  },
  {
    id: "apr-002",
    timestamp: new Date(Date.now() - 1000 * 60 * 7).toISOString(),
    proposedAction: "Execute shell command to compress logs",
    tool: "shell.exec",
    resource: "/var/log/secure-rag/*.log",
    recipient: "local system (operator)",
    reason:
      "Privileged shell execution requested. Resource path includes sensitive log files. Verify the operator has authorized this action.",
  },
  {
    id: "apr-003",
    timestamp: new Date(Date.now() - 1000 * 60 * 14).toISOString(),
    proposedAction: "Web search on external domain",
    tool: "web.search",
    resource: "https://attacker.example",
    recipient: "—",
    reason:
      "Query targets a domain flagged on the watch-list. Verify the search is intended and safe before allowing retrieval.",
  },
];

function fmtTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

export default function ApprovalsPage() {
  const [items, setItems] = useState<ApprovalItem[]>(SEED_APPROVALS);

  const resolve = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  return (
    <PageShell>
      <div className="grid w-full grid-cols-1 gap-5 lg:grid-cols-12">
        <Reveal className="lg:col-span-12" delay={0}>
          <section className="card card-pad h-full">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="section-title">Approval Queue</h2>
              <span
                className="chip border border-status-warn/40 bg-status-warn/10 text-status-warn"
                style={{ boxShadow: "var(--shadow-glow-yellow)" }}
              >
                {items.length} pending
              </span>
            </div>

            {items.length === 0 ? (
              <div className="surface-sunken flex flex-col items-center gap-3 p-12 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-status-allow/10 text-status-allow">
                  <CheckIcon size={24} />
                </div>
                <p className="text-sm text-slate-400">
                  No actions are currently awaiting human confirmation.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {items.map((item) => (
                  <ApprovalCard key={item.id} item={item} onResolve={resolve} />
                ))}
              </div>
            )}
          </section>
        </Reveal>
      </div>
    </PageShell>
  );
}

const ApprovalCard: React.FC<{
  item: ApprovalItem;
  onResolve: (id: string) => void;
}> = ({ item, onResolve }) => {
  return (
    <div
      className="hover-lift rounded-xl border border-status-warn/30 bg-ink-850 p-5"
      style={{ boxShadow: "var(--shadow-glow-yellow)" }}
    >
      {/* Header row */}
      <div className="mb-4 flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-status-warn/40 bg-status-warn/10 text-status-warn"
          >
            <AlertTriangle size={18} />
          </div>
          <div>
            <div className="text-[15px] font-semibold text-white">
              {item.proposedAction}
            </div>
            <div className="text-[11px] tabular-nums text-slate-500">
              queued at {fmtTime(item.timestamp)} · {item.id}
            </div>
          </div>
        </div>
        <span className="chip border border-status-warn/40 bg-status-warn/10 text-[10px] font-semibold uppercase tracking-wider text-status-warn">
          awaiting review
        </span>
      </div>

      {/* Detail grid */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Field label="Proposed action" value={item.proposedAction} />
        <Field label="Tool" value={item.tool} mono />
        <Field label="Resource" value={item.resource} mono />
        <Field label="Recipient" value={item.recipient} mono />
        <div className="sm:col-span-2 lg:col-span-4">
          <Field label="Reason" value={item.reason} block />
        </div>
      </div>

      {/* Action buttons */}
      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="button"
          className="btn btn-success"
          onClick={() => onResolve(item.id)}
        >
          <CheckIcon size={16} />
          Approve
        </button>
        <button
          type="button"
          className="btn btn-danger"
          onClick={() => onResolve(item.id)}
        >
          <XIcon size={16} />
          Reject
        </button>
      </div>
    </div>
  );
};

const Field: React.FC<{
  label: string;
  value: string;
  mono?: boolean;
  block?: boolean;
}> = ({ label, value, mono, block }) => (
  <div className={`surface-sunken p-3 ${block ? "w-full" : ""}`}>
    <div className="mb-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-500">
      {label}
    </div>
    <div
      className={`text-[13px] leading-snug text-slate-200 ${
        mono ? "font-mono text-[12px]" : ""
      }`}
    >
      {value}
    </div>
  </div>
);

// Inline alert triangle icon (kept local to avoid an extra import cycle)
const AlertTriangle: React.FC<{ size?: number }> = ({ size = 18 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={1.8}
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M12 3l10 18H2L12 3z" />
    <line x1="12" y1="10" x2="12" y2="14" />
    <circle cx="12" cy="17.5" r="0.6" fill="currentColor" />
  </svg>
);
