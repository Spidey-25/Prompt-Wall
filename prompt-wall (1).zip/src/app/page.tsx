"use client";

import React from "react";
import Link from "next/link";
import PageShell from "@/components/secure-rag/PageShell";
import Reveal from "@/components/secure-rag/Reveal";
import MetricsStrip from "@/components/secure-rag/MetricsStrip";
import LiveEventStream from "@/components/secure-rag/LiveEventStream";
import { SEED_METRICS_STRIP, SEED_LIVE_EVENTS } from "@/lib/secure-rag/mockData";
import { ShieldIcon, PlayIcon, FlaskIcon, CheckIcon } from "@/components/secure-rag/icons";

/**
 * Home — Security Command Center.
 * Hero + system health + live threat stats + recent events + architecture.
 */
export default function HomePage() {
  return (
    <PageShell>
      <div className="grid w-full grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Hero */}
        <Reveal className="lg:col-span-12" delay={0}>
          <section className="card card-pad relative overflow-hidden h-full">
            <div
              className="pointer-events-none absolute inset-0 opacity-30"
              style={{
                background:
                  "radial-gradient(600px 300px at 10% 0%, rgba(255, 106, 0, 0.25), transparent 60%), radial-gradient(500px 250px at 90% 100%, rgba(255, 194, 26, 0.15), transparent 55%)",
              }}
            />
            <div className="relative flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
              <div className="max-w-2xl">
                <div className="flex items-center gap-2">
                  <ShieldIcon size={28} className="text-accent-blue" />
                  <h1 className="text-4xl font-extrabold tracking-tight text-white md:text-5xl">
                    PROMPT<span className="text-gradient-warm">WALL</span>
                  </h1>
                </div>
                <p className="mt-3 text-base text-slate-400 md:text-lg">
                  Protect AI agents from prompt injection and unauthorized actions.
                </p>
                <div className="mt-5 flex flex-wrap gap-3">
                  <Link href="/playground" className="btn btn-primary text-base">
                    <PlayIcon size={16} />
                    Start Secure Task
                  </Link>
                  <Link
                    href="/security-testing"
                    className="btn-ghost btn border border-ink-600 bg-ink-800 text-slate-200"
                  >
                    <FlaskIcon size={16} />
                    Run Security Test
                  </Link>
                </div>
              </div>

              {/* Protection active badge */}
              <div
                className="shrink-0 rounded-xl border border-status-allow/30 bg-status-allow/5 p-4"
                style={{ boxShadow: "var(--shadow-glow-green)" }}
              >
                <div className="flex items-center gap-2">
                  <span className="inline-block h-2 w-2 rounded-full bg-status-allow animate-pulse-soft" />
                  <span className="text-sm font-bold uppercase tracking-wider text-status-allow">
                    Protection Active
                  </span>
                </div>
                <div className="mt-1 text-[11px] text-slate-500">
                  All security layers online
                </div>
              </div>
            </div>
          </section>
        </Reveal>

        {/* Metrics strip */}
        <Reveal className="lg:col-span-12" delay={80}>
          <MetricsStrip metrics={SEED_METRICS_STRIP} />
        </Reveal>

        {/* System health + Architecture */}
        <Reveal className="lg:col-span-7" delay={100}>
          <section className="card card-pad h-full">
            <h2 className="section-title mb-4">System Health</h2>
            <div className="space-y-2.5">
              {[
                { name: "Content Firewall", status: "ONLINE", color: "#22C55E" },
                { name: "Scope Engine", status: "ONLINE", color: "#22C55E" },
                { name: "Action Guard", status: "ONLINE", color: "#22C55E" },
                { name: "Provenance Engine", status: "ONLINE", color: "#22C55E" },
                { name: "Audit Engine", status: "ONLINE", color: "#22C55E" },
              ].map((sys) => (
                <div
                  key={sys.name}
                  className="flex items-center justify-between rounded-lg border border-ink-600 bg-ink-850 px-4 py-2.5"
                  style={{ boxShadow: "var(--shadow-3d-sm)" }}
                >
                  <span className="text-[13px] font-medium text-slate-200">
                    {sys.name}
                  </span>
                  <span className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider" style={{ color: sys.color }}>
                    <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: sys.color, boxShadow: `0 0 6px ${sys.color}` }} />
                    {sys.status}
                  </span>
                </div>
              ))}
            </div>
          </section>
        </Reveal>

        {/* Architecture diagram */}
        <Reveal className="lg:col-span-5" delay={200}>
          <section className="card card-pad h-full">
            <h2 className="section-title mb-4">Architecture</h2>
            <div className="flex flex-col items-center gap-2">
              {[
                { label: "UNTRUSTED CONTENT", color: "#EF4444" },
                { label: "CONTENT FIREWALL", color: "#FF6A00" },
                { label: "AI AGENT", color: "#A1A1A1" },
                { label: "ACTION GUARD", color: "#FF6A00" },
                { label: "ALLOW / BLOCK / ASK HUMAN", color: "#22C55E" },
              ].map((node, idx, arr) => (
                <React.Fragment key={node.label}>
                  <div
                    className="w-full rounded-lg border px-4 py-2.5 text-center text-[12px] font-bold uppercase tracking-wider"
                    style={{
                      borderColor: `${node.color}50`,
                      background: `${node.color}10`,
                      color: node.color,
                      boxShadow: `0 0 12px -4px ${node.color}40`,
                    }}
                  >
                    {node.label}
                  </div>
                  {idx < arr.length - 1 && (
                    <div className="h-4 w-px bg-ink-600" />
                  )}
                </React.Fragment>
              ))}
            </div>
          </section>
        </Reveal>

        {/* Live security events */}
        <Reveal className="lg:col-span-12" delay={150}>
          <LiveEventStream events={SEED_LIVE_EVENTS} />
        </Reveal>
      </div>
    </PageShell>
  );
}
