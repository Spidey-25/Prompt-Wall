"use client";

import React, { useState } from "react";
import type { EvaluationMetrics } from "@/types";
import PageShell from "@/components/secure-rag/PageShell";
import Evaluation from "@/components/secure-rag/Evaluation";
import Reveal from "@/components/secure-rag/Reveal";
import { SEED_METRICS } from "@/lib/secure-rag/mockData";
import { CheckIcon, XIcon } from "@/components/secure-rag/icons";

/**
 * Evaluation — proves the PS requirements are being met.
 * KPI cards + charts placeholder + requirement checklist.
 *
 * NOTE: these values are mock for now. The real numbers must come from
 * the actual evaluation engine — do not fake successful metrics in the
 * final application.
 */
const REQUIREMENT_CHECKLIST: { label: string; target: string; met: boolean; value: string }[] = [
  { label: "Baseline vulnerability", target: "≥ 70%", met: true, value: "78.4%" },
  { label: "Development catch rate", target: "≥ 85%", met: true, value: "96.4%" },
  { label: "Benign completion", target: "≥ 90%", met: true, value: "98.7%" },
  { label: "False-positive rate", target: "≤ 10%", met: true, value: "2.1%" },
  { label: "Added latency", target: "< 2 seconds", met: true, value: "1.31s" },
  { label: "Audit evidence available", target: "yes", met: true, value: "yes" },
];

const CHART_PLACEHOLDERS: { title: string; subtitle: string }[] = [
  { title: "Attack Detection by Category", subtitle: "Plain · Encoded · Fake System · Tool-Response · Multi-Step" },
  { title: "Baseline vs Protected Results", subtitle: "Hijack rate comparison across attack suite" },
  { title: "Detection Rate Over Test Runs", subtitle: "Trend across the last 10 evaluation runs" },
  { title: "False-Positive Rate", subtitle: "Per-category FP breakdown" },
  { title: "Latency Breakdown", subtitle: "Per-stage added latency (ms)" },
  { title: "Benign vs Malicious Outcomes", subtitle: "Task completion distribution" },
];

export default function EvaluationPage() {
  const [metrics] = useState<EvaluationMetrics>(SEED_METRICS);

  return (
    <PageShell>
      <div className="grid w-full grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Hero */}
        <Reveal className="lg:col-span-12" delay={0}>
          <section className="card card-pad h-full">
            <h1 className="text-3xl font-extrabold tracking-tight text-white md:text-4xl">
              Evaluation
            </h1>
            <p className="mt-2 text-sm text-slate-400 md:text-base">
              Proof that the PromptWall security requirements are being met. Metrics below
              are mock — the final application must source these from the real evaluation engine.
            </p>
          </section>
        </Reveal>

        {/* KPI cards */}
        <Reveal className="lg:col-span-12" delay={80}>
          <Evaluation metrics={metrics} />
        </Reveal>

        {/* Charts grid */}
        <Reveal className="lg:col-span-12" delay={120}>
          <section className="card card-pad h-full">
            <h2 className="section-title mb-4">Charts</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {CHART_PLACEHOLDERS.map((c) => (
                <div
                  key={c.title}
                  className="surface-sunken flex flex-col p-4"
                  style={{ minHeight: "180px" }}
                >
                  <div className="text-[13px] font-semibold text-slate-200">
                    {c.title}
                  </div>
                  <div className="mt-1 text-[11px] text-slate-500">
                    {c.subtitle}
                  </div>
                  {/* Chart placeholder — wire to real chart lib + evaluation data later */}
                  <div className="mt-auto flex h-20 items-center justify-center text-[11px] text-slate-600">
                    [ chart renders here ]
                  </div>
                </div>
              ))}
            </div>
          </section>
        </Reveal>

        {/* Requirement checklist */}
        <Reveal className="lg:col-span-12" delay={150}>
          <section className="card card-pad h-full">
            <h2 className="section-title mb-4">Requirement Checklist</h2>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {REQUIREMENT_CHECKLIST.map((r) => (
                <div
                  key={r.label}
                  className="flex items-center justify-between rounded-lg border border-ink-600 bg-ink-850 px-4 py-2.5"
                  style={{ boxShadow: "var(--shadow-3d-sm)" }}
                >
                  <div>
                    <div className="text-[13px] font-medium text-slate-200">
                      {r.label}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      target: {r.target} · actual: {r.value}
                    </div>
                  </div>
                  {r.met ? (
                    <CheckIcon size={18} className="text-status-allow" />
                  ) : (
                    <XIcon size={18} className="text-status-block" />
                  )}
                </div>
              ))}
            </div>
          </section>
        </Reveal>
      </div>
    </PageShell>
  );
}
