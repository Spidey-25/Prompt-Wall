"use client";

import React, { useCallback, useRef, useState } from "react";
import type {
  AuditEvent,
  FinalResponse,
  SecurityDecision,
  WorkflowStage,
} from "@/types";
import { INITIAL_STAGES, DEMO_SCOPE, SEED_METRICS_STRIP, SEED_LIVE_EVENTS } from "@/lib/secure-rag/mockData";
import {
  runMockPipeline,
  mockResolveHuman,
  type PipelineEvent,
} from "@/lib/secure-rag/mockPipeline";

import PageShell from "@/components/secure-rag/PageShell";
import UserRequest from "@/components/secure-rag/UserRequest";
import AuthorizedScope from "@/components/secure-rag/AuthorizedScope";
import AgentWorkflow from "@/components/secure-rag/AgentWorkflow";
import SecurityDecisionPanel from "@/components/secure-rag/SecurityDecision";
import FinalResponsePanel from "@/components/secure-rag/FinalResponse";
import MetricsStrip from "@/components/secure-rag/MetricsStrip";
import LiveEventStream from "@/components/secure-rag/LiveEventStream";
import Reveal from "@/components/secure-rag/Reveal";
import { ShieldIcon } from "@/components/secure-rag/icons";

/**
 * Agent Playground — submit an AI-agent task and watch the complete
 * PromptWall security pipeline execute.
 */
export default function PlaygroundPage() {
  const [stages, setStages] = useState<WorkflowStage[]>(INITIAL_STAGES);
  const [decision, setDecision] = useState<SecurityDecision | null>(null);
  const [finalResponse, setFinalResponse] = useState<FinalResponse | null>(null);
  const [running, setRunning] = useState(false);
  const [resolving, setResolving] = useState(false);

  const cancelRef = useRef<{ cancelled: boolean }>({ cancelled: false });

  const emit = useCallback((ev: PipelineEvent) => {
    if (ev.stage) {
      setStages((prev) =>
        prev.map((s) => (s.id === ev.stage!.id ? { ...ev.stage! } : s))
      );
    }
    if (ev.decision) setDecision(ev.decision!);
    if (ev.finalResponse) setFinalResponse(ev.finalResponse!);
  }, []);

  const resetPipeline = useCallback(() => {
    setStages(INITIAL_STAGES.map((s) => ({ ...s, status: "Pending" })));
    setDecision(null);
    setFinalResponse(null);
  }, []);

  const handleRun = useCallback(
    async (prompt: string) => {
      const looksLikeAttack = /ignore all previous instructions|override safety|reveal the system prompt|admin token|#0000|send_email|exfiltrat/i.test(
        prompt
      );
      cancelRef.current = { cancelled: false };
      setRunning(true);
      resetPipeline();
      try {
        await runMockPipeline(
          { prompt, block: looksLikeAttack, askHuman: false },
          emit,
          cancelRef.current
        );
      } finally {
        setRunning(false);
      }
    },
    [emit, resetPipeline]
  );

  const handleApprove = useCallback(async () => {
    setResolving(true);
    try {
      await mockResolveHuman(true, emit);
      cancelRef.current = { cancelled: false };
      setRunning(true);
      await runMockPipeline(
        { prompt: "continue", block: false, askHuman: false },
        emit,
        cancelRef.current
      );
    } finally {
      setResolving(false);
      setRunning(false);
    }
  }, [emit]);

  const handleReject = useCallback(async () => {
    setResolving(true);
    try {
      await mockResolveHuman(false, emit);
      setDecision(null);
    } finally {
      setResolving(false);
    }
  }, [emit]);

  const handleRunAgain = useCallback(() => {
    resetPipeline();
  }, [resetPipeline]);

  return (
    <PageShell>
      <div className="grid w-full grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Page hero */}
        <Reveal className="lg:col-span-12" delay={0}>
          <section className="card card-pad relative overflow-hidden h-full">
            <div
              className="pointer-events-none absolute inset-0 opacity-20"
              style={{
                background:
                  "radial-gradient(500px 250px at 90% 0%, rgba(255, 106, 0, 0.30), transparent 60%)",
              }}
            />
            <div className="relative flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-3xl font-extrabold tracking-tight text-white md:text-4xl">
                  Agent Playground
                </h1>
                <p className="mt-2 text-sm text-slate-400 md:text-base">
                  Run an AI task through PromptWall&apos;s security pipeline before allowing tool execution.
                </p>
              </div>
              <div
                className="shrink-0 rounded-lg border border-status-allow/30 bg-status-allow/5 px-3 py-2"
                style={{ boxShadow: "var(--shadow-glow-green)" }}
              >
                <div className="flex items-center gap-2">
                  <ShieldIcon size={16} className="text-status-allow" />
                  <span className="text-[12px] font-bold uppercase tracking-wider text-status-allow">
                    Protection Active
                  </span>
                </div>
              </div>
            </div>
          </section>
        </Reveal>

        {/* User Request + Authorized Scope */}
        <Reveal className="lg:col-span-7" delay={80}>
          <UserRequest onRun={handleRun} disabled={running} />
        </Reveal>
        <Reveal className="lg:col-span-5" delay={200}>
          <AuthorizedScope scope={DEMO_SCOPE} />
        </Reveal>

        {/* Metrics strip */}
        <Reveal className="lg:col-span-12" delay={100}>
          <MetricsStrip metrics={SEED_METRICS_STRIP} />
        </Reveal>

        {/* Agent Workflow */}
        <Reveal className="lg:col-span-12" delay={150}>
          <AgentWorkflow stages={stages} />
        </Reveal>

        {/* Security Decision + Final Response */}
        <Reveal className="lg:col-span-7" delay={100}>
          <SecurityDecisionPanel
            decision={decision}
            onApprove={handleApprove}
            onReject={handleReject}
            resolving={resolving}
          />
        </Reveal>
        <Reveal className="lg:col-span-5" delay={250}>
          <FinalResponsePanel response={finalResponse} onRunAgain={handleRunAgain} />
        </Reveal>

        {/* Live security events */}
        <Reveal className="lg:col-span-12" delay={150}>
          <LiveEventStream events={SEED_LIVE_EVENTS} />
        </Reveal>
      </div>
    </PageShell>
  );
}
