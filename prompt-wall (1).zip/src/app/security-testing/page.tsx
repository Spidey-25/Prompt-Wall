"use client";

import React, { useCallback, useState } from "react";
import type { AttackCategory, AttackDef, AttackRunResult } from "@/types";
import PageShell from "@/components/secure-rag/PageShell";
import Reveal from "@/components/secure-rag/Reveal";
import { CheckIcon, XIcon, FlaskIcon } from "@/components/secure-rag/icons";
import {
  ATTACK_CATEGORIES,
  ATTACK_LIBRARY,
  attacksForCategory,
} from "@/lib/secure-rag/mockData";

/**
 * Security Testing — dedicated red-team surface.
 * Includes: Attack category, Attack scenario, Run Attack,
 * Protected/Unprotected comparison, Attack result.
 */
export default function SecurityTestingPage() {
  const [category, setCategory] = useState<AttackCategory>(ATTACK_CATEGORIES[0]);
  const [attackId, setAttackId] = useState(
    attacksForCategory(ATTACK_CATEGORIES[0])[0].id
  );
  const [result, setResult] = useState<AttackRunResult | null>(null);
  const [running, setRunning] = useState(false);

  const attacks = attacksForCategory(category);
  const selectedAttack =
    ATTACK_LIBRARY.find((a) => a.id === attackId) ?? attacks[0];

  const onChangeCategory = (cat: AttackCategory) => {
    setCategory(cat);
    setAttackId(attacksForCategory(cat)[0].id);
    setResult(null);
  };

  const handleRun = useCallback(async (attack: AttackDef) => {
    setRunning(true);
    setResult(null);
    await new Promise((r) => setTimeout(r, 1300));
    const bypassed = attack.id === "ms-02";
    const r: AttackRunResult = bypassed
      ? {
          attackId: attack.id,
          result: "BYPASSED",
          detail:
            "Translation-based exfiltration bypassed the content firewall. Tuning required for multi-step obfuscation patterns.",
        }
      : {
          attackId: attack.id,
          result: "BLOCKED",
          detail: `Blocked at ${
            attack.category === "Plain Injection" ||
            attack.category === "Fake System Message"
              ? "Content Firewall"
              : attack.category === "Encoded Injection"
              ? "Content Firewall (decoder)"
              : "Action Guard"
          }.`,
        };
    setResult(r);
    setRunning(false);
  }, []);

  return (
    <PageShell>
      <div className="grid w-full grid-cols-1 gap-5 lg:grid-cols-12">
        {/* Attack selector + Run */}
        <Reveal className="lg:col-span-7" delay={0}>
          <section className="card card-pad h-full">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="section-title">Attack Configuration</h2>
              <span className="chip border border-ink-600 bg-ink-850 text-slate-400">
                <FlaskIcon size={13} />
                red-team harness
              </span>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
                  Attack category
                </label>
                <select
                  className="input-base"
                  value={category}
                  onChange={(e) => onChangeCategory(e.target.value as AttackCategory)}
                  disabled={running}
                >
                  {ATTACK_CATEGORIES.map((c) => (
                    <option key={c} value={c} className="bg-ink-900 text-white">
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
                  Attack scenario
                </label>
                <select
                  className="input-base"
                  value={attackId}
                  onChange={(e) => setAttackId(e.target.value)}
                  disabled={running}
                >
                  {attacks.map((a) => (
                    <option key={a.id} value={a.id} className="bg-ink-900 text-white">
                      {a.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="mt-4">
              <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
                Payload preview
              </div>
              <pre className="surface-sunken max-h-40 overflow-auto p-4 font-mono text-[12.5px] leading-snug text-slate-300">
{selectedAttack?.payload ?? ""}
              </pre>
            </div>

            <div className="mt-4 flex justify-end">
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => selectedAttack && handleRun(selectedAttack)}
                disabled={running || !selectedAttack}
              >
                <FlaskIcon size={16} />
                {running ? "Running Attack…" : "Run Attack"}
              </button>
            </div>
          </section>
        </Reveal>

        {/* Result + Protected/Unprotected comparison */}
        <Reveal className="lg:col-span-5" delay={150}>
          <section className="card card-pad h-full">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="section-title">Result</h2>
              <span className="text-[11px] text-slate-500">
                {result ? "complete" : "pending"}
              </span>
            </div>

            {/* Verdict */}
            {!result ? (
              <div className="surface-sunken flex items-center gap-3 p-4 text-sm text-slate-400">
                <FlaskIcon size={18} />
                Run an attack to see the protected vs unprotected outcome.
              </div>
            ) : (
              <div
                className="hover-lift rounded-xl border p-4"
                style={{
                  borderColor: `${result.result === "BLOCKED" ? "#22C55E" : "#EF4444"}55`,
                  background:
                    result.result === "BLOCKED"
                      ? "rgba(34, 197, 94, 0.08)"
                      : "rgba(239, 68, 68, 0.08)",
                  boxShadow: result.result === "BLOCKED"
                    ? "var(--shadow-glow-green)"
                    : "var(--shadow-glow-red)",
                }}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="flex h-9 w-9 items-center justify-center rounded-lg"
                    style={{
                      color: result.result === "BLOCKED" ? "#22C55E" : "#EF4444",
                      background: result.result === "BLOCKED" ? "rgba(34,197,94,0.15)" : "rgba(239,68,68,0.15)",
                    }}
                  >
                    {result.result === "BLOCKED" ? <CheckIcon size={18} /> : <XIcon size={18} />}
                  </div>
                  <div>
                    <div
                      className="text-lg font-extrabold tracking-wide"
                      style={{ color: result.result === "BLOCKED" ? "#22C55E" : "#EF4444" }}
                    >
                      {result.result}
                    </div>
                    <div className="text-xs text-slate-400">
                      {result.result === "BLOCKED"
                        ? "PromptWall caught the attack."
                        : "The attack slipped past the firewall."}
                    </div>
                  </div>
                </div>
                {result.detail && (
                  <div className="surface-sunken mt-3 p-3 text-[12.5px] text-slate-300">
                    {result.detail}
                  </div>
                )}
              </div>
            )}

            {/* Protected vs Unprotected comparison */}
            <div className="mt-5">
              <div className="mb-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
                Protected vs Unprotected
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="surface-sunken p-3">
                  <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-status-allow">
                    With PromptWall
                  </div>
                  <div className="text-[13px] font-semibold text-white">
                    {result?.result === "BYPASSED" ? "Bypassed" : "Blocked"}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {result?.result === "BYPASSED"
                      ? "Tuning required"
                      : "Action stopped at the firewall"}
                  </div>
                </div>
                <div className="surface-sunken p-3">
                  <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-status-block">
                    Unprotected
                  </div>
                  <div className="text-[13px] font-semibold text-white">Compromised</div>
                  <div className="text-[11px] text-slate-500">
                    Agent would execute the malicious action
                  </div>
                </div>
              </div>
            </div>
          </section>
        </Reveal>
      </div>
    </PageShell>
  );
}
