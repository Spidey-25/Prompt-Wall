"use client";

import React, { useState } from "react";
import type { AuditEvent, AuditStatus } from "@/types";
import PageShell from "@/components/secure-rag/PageShell";
import Reveal from "@/components/secure-rag/Reveal";
import { SEED_AUDIT_LOG } from "@/lib/secure-rag/mockData";

/**
 * Audit Logs — professional dark table interface.
 * Columns: Timestamp, Event, Security decision, Evidence, Rule violated, Tool, Status.
 */
type TableRow = AuditEvent & {
  decision: string;
  evidence: string;
  rule: string;
  tool: string;
};

const TABLE_ROWS: TableRow[] = [
  {
    ...SEED_AUDIT_LOG[2],
    decision: "ALLOW",
    evidence: "6 chunks · clean",
    rule: "—",
    tool: "rag.retrieve",
  },
  {
    ...SEED_AUDIT_LOG[1],
    decision: "ALLOW",
    evidence: "Query scoped to public docs",
    rule: "T-001 · Tool scope",
    tool: "web.search",
  },
  {
    id: "evt-0004",
    timestamp: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
    eventType: "THREAT_DETECTED",
    status: "danger",
    description: "Prompt-injection signature matched.",
    decision: "BLOCK",
    evidence: "“Ignore all previous instructions…”",
    rule: "P-Inj-002 · Instruction override",
    tool: "rag.summarize",
  },
  {
    id: "evt-0005",
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
    eventType: "HUMAN_CONFIRMATION",
    status: "warning",
    description: "Out-of-scope domain request — awaiting operator decision.",
    decision: "ASK HUMAN",
    evidence: "Query targets external domain",
    rule: "T-014 · External resource",
    tool: "web.search",
  },
  {
    ...SEED_AUDIT_LOG[0],
    decision: "ALLOW",
    evidence: "3 tools executed, 0 threats",
    rule: "—",
    tool: "agent.run",
  },
];

const DECISION_COLOR: Record<string, string> = {
  ALLOW: "#22C55E",
  BLOCK: "#EF4444",
  "ASK HUMAN": "#F59E0B",
};

const STATUS_COLOR: Record<AuditStatus, string> = {
  info: "#FF6A00",
  success: "#22C55E",
  warning: "#F59E0B",
  danger: "#EF4444",
};

function fmtTime(iso: string): string {
  const d = new Date(iso);
  const date = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  const time = d.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
  return `${date} · ${time}`;
}

const COLUMNS: { key: string; label: string; className?: string }[] = [
  { key: "timestamp", label: "Timestamp", className: "w-[200px]" },
  { key: "event", label: "Event", className: "w-[180px]" },
  { key: "decision", label: "Decision", className: "w-[120px]" },
  { key: "evidence", label: "Evidence" },
  { key: "rule", label: "Rule violated", className: "w-[220px]" },
  { key: "tool", label: "Tool", className: "w-[140px]" },
  { key: "status", label: "Status", className: "w-[100px] text-right" },
];

export default function AuditLogsPage() {
  const [rows] = useState<TableRow[]>(TABLE_ROWS);
  const [search, setSearch] = useState("");
  const [riskFilter, setRiskFilter] = useState("all");
  const [decisionFilter, setDecisionFilter] = useState("all");

  const filtered = rows.filter((r) => {
    const matchesSearch =
      !search ||
      r.description.toLowerCase().includes(search.toLowerCase()) ||
      r.eventType.toLowerCase().includes(search.toLowerCase()) ||
      r.tool.toLowerCase().includes(search.toLowerCase()) ||
      r.rule.toLowerCase().includes(search.toLowerCase());
    const matchesDecision =
      decisionFilter === "all" || r.decision === decisionFilter;
    const matchesRisk =
      riskFilter === "all" ||
      (riskFilter === "danger" && r.status === "danger") ||
      (riskFilter === "warning" && r.status === "warning") ||
      (riskFilter === "success" && r.status === "success") ||
      (riskFilter === "info" && r.status === "info");
    return matchesSearch && matchesDecision && matchesRisk;
  });

  return (
    <PageShell>
      <div className="grid w-full grid-cols-1 gap-5 lg:grid-cols-12">
        <Reveal className="lg:col-span-12" delay={0}>
          <section className="card h-full overflow-hidden">
            {/* Filter bar */}
            <div className="flex flex-col gap-3 border-b border-ink-600 px-6 py-4 md:flex-row md:items-center md:justify-between">
              <h2 className="section-title">Audit Log</h2>
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search…"
                    className="input-base w-44 rounded-lg py-1.5 text-[12.5px] md:w-56"
                  />
                </div>
                <select
                  value={riskFilter}
                  onChange={(e) => setRiskFilter(e.target.value)}
                  className="input-base w-28 rounded-lg py-1.5 text-[12px]"
                >
                  <option value="all" className="bg-ink-900">All risk</option>
                  <option value="danger" className="bg-ink-900">High</option>
                  <option value="warning" className="bg-ink-900">Medium</option>
                  <option value="info" className="bg-ink-900">Info</option>
                  <option value="success" className="bg-ink-900">Success</option>
                </select>
                <select
                  value={decisionFilter}
                  onChange={(e) => setDecisionFilter(e.target.value)}
                  className="input-base w-32 rounded-lg py-1.5 text-[12px]"
                >
                  <option value="all" className="bg-ink-900">All decisions</option>
                  <option value="ALLOW" className="bg-ink-900">Allow</option>
                  <option value="BLOCK" className="bg-ink-900">Block</option>
                  <option value="ASK HUMAN" className="bg-ink-900">Ask Human</option>
                </select>
              </div>
            </div>

            {/* Dark table */}
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1000px] border-collapse text-left">
                <thead>
                  <tr className="border-b border-ink-600">
                    {COLUMNS.map((c) => (
                      <th
                        key={c.key}
                        className={`px-6 py-3 text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-500 ${c.className ?? ""}`}
                      >
                        {c.label}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((row) => {
                    const dColor = DECISION_COLOR[row.decision] ?? "#A1A1A1";
                    const sColor = STATUS_COLOR[row.status];
                    return (
                      <tr
                        key={row.id}
                        className="border-b border-ink-700 transition-colors hover:bg-ink-800/60"
                      >
                        <td className="px-6 py-3 font-mono text-[12px] tabular-nums text-slate-400">
                          {fmtTime(row.timestamp)}
                        </td>
                        <td className="px-6 py-3">
                          <span
                            className="inline-flex items-center gap-1.5 rounded border border-ink-600 bg-ink-850 px-2 py-0.5 font-mono text-[10px] font-semibold"
                            style={{ color: sColor }}
                          >
                            <span
                              className="inline-block h-1.5 w-1.5 rounded-full"
                              style={{ background: sColor, boxShadow: `0 0 6px ${sColor}` }}
                            />
                            {row.eventType}
                          </span>
                        </td>
                        <td className="px-6 py-3">
                          <span
                            className="font-mono text-[11px] font-bold uppercase tracking-wider"
                            style={{ color: dColor }}
                          >
                            {row.decision}
                          </span>
                        </td>
                        <td className="px-6 py-3 text-[13px] text-slate-300">
                          {row.evidence}
                        </td>
                        <td className="px-6 py-3 font-mono text-[12px] text-slate-400">
                          {row.rule}
                        </td>
                        <td className="px-6 py-3 font-mono text-[12px] text-slate-400">
                          {row.tool}
                        </td>
                        <td className="px-6 py-3 text-right">
                          <span
                            className="inline-flex items-center justify-end gap-1.5 text-[11px] font-semibold uppercase tracking-wider"
                            style={{ color: sColor }}
                          >
                            <span
                              className="inline-block h-1.5 w-1.5 rounded-full"
                              style={{ background: sColor }}
                            />
                            {row.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between border-t border-ink-600 px-6 py-3 text-[11px] text-slate-500">
              <span>Showing {filtered.length} of {rows.length} entries</span>
              <span className="font-mono">Real-time stream: Socket.IO · pipeline:event</span>
            </div>
          </section>
        </Reveal>
      </div>
    </PageShell>
  );
}
