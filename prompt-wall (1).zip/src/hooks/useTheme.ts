"use client";

import { useCallback, useEffect } from "react";

type Theme = "dark" | "light";

const STORAGE_KEY = "promptwall-theme";

/**
 * useTheme — manages light/dark theme with localStorage persistence.
 *
 * Theme state is stored as the `light` / `dark` class on <html>.
 * Icon visibility is CSS-controlled (`.theme-icon-dark` / `.theme-icon-light`)
 * so there's no hydration mismatch and no setState-in-effect.
 */
export function useTheme() {
  // Apply the stored theme on mount (no state needed — the DOM is the source of truth)
  useEffect(() => {
    const stored = (localStorage.getItem(STORAGE_KEY) as Theme | null) ?? "dark";
    const html = document.documentElement;
    html.classList.toggle("light", stored === "light");
    html.classList.toggle("dark", stored === "dark");
  }, []);

  const toggle = useCallback(() => {
    const html = document.documentElement;
    const isLight = html.classList.contains("light");
    const next: Theme = isLight ? "dark" : "light";
    html.classList.toggle("light", next === "light");
    html.classList.toggle("dark", next === "dark");
    localStorage.setItem(STORAGE_KEY, next);
  }, []);

  return { toggle };
}
