"""
Agent state schema for the PromptWall LangGraph Agent (Stage 8 — Action Guard).
"""

from typing import Any, Dict, List, Optional
from typing_extensions import TypedDict


class AgentState(TypedDict):
    """Complete state object passed through LangGraph nodes."""

    # ---- Input ----
    user_request: str

    # ---- Scope Extractor (Stage 7) ----
    scope: Optional[Dict[str, Any]]            # Extracted task scope from trusted user request

    # ---- RAG ----
    retrieved_context: List[Dict[str, Any]]   # List of dicts {source_id, text}

    # ---- Content Firewall (Stage 6) ----
    firewall_result: Optional[Dict[str, Any]]  # Summary of Content Firewall inspection

    # ---- Conversation / Reasoning ----
    messages: List[Dict[str, str]]             # List of dicts {role, content}

    # ---- Tool Execution ----
    proposed_tool: Optional[str]              # Name of current proposed tool
    tool_arguments: Optional[Dict[str, Any]]  # Arguments for proposed tool
    tool_result: Optional[Any]                # Result returned from executed tool
    tool_calls: List[Dict[str, Any]]          # History of tool calls [{tool, arguments}]
    tool_results: List[Dict[str, Any]]        # History of tool results [{tool, result}]

    # ---- Action Guard (Stage 8) ----
    action_guard_result: Optional[Dict[str, Any]]  # Action Guard decision for current proposal

    # ---- Control Flow ----
    step_count: int                           # Step counter for multi-step loops

    # ---- Output ----
    final_response: Optional[str]

    # ---- Metadata ----
    metadata: Dict[str, Any]
