"""
Agent Service — Wrapper orchestrating the Stage 8 LangGraph Agent with Action Guard.

Workflow:
  API route → AgentService.run() → LangGraph (Scope → RAG → Firewall → Reasoning → Guard → Tools) → Response
"""

from typing import Any, Dict, List
from agent.graph import agent_graph
from agent.state import AgentState


class AgentService:
    """Invoke the Stage 8 LangGraph Agent pipeline with Action Guard."""

    @staticmethod
    def run(message: str) -> Dict[str, Any]:
        """
        Execute the Stage 8 LangGraph agent for a user message.
        Returns a dict matching the Stage 8 API response format.
        """
        initial_state: AgentState = {
            "user_request": message,
            "scope": None,
            "retrieved_context": [],
            "firewall_result": None,
            "messages": [],
            "final_response": None,
            "proposed_tool": None,
            "tool_arguments": None,
            "tool_result": None,
            "tool_calls": [],
            "tool_results": [],
            "action_guard_result": None,
            "step_count": 0,
            "metadata": {},
        }

        # Execute LangGraph workflow
        final_state: AgentState = agent_graph.invoke(initial_state)

        extracted_scope: Dict[str, Any] = final_state.get("scope") or {}
        retrieved_context: List[Dict[str, Any]] = final_state.get("retrieved_context", [])
        firewall_result: Dict[str, Any] = final_state.get("firewall_result") or {
            "status": "CLEAN",
            "classification": "SAFE",
            "confidence": 1.0,
            "detections": [],
        }
        action_guard_result: Dict[str, Any] = final_state.get("action_guard_result") or {}
        tool_calls: List[Dict[str, Any]] = final_state.get("tool_calls", [])
        tool_results: List[Dict[str, Any]] = final_state.get("tool_results", [])

        # Extract last tool used for backwards compatibility
        last_tool = tool_calls[-1].get("tool") if tool_calls else None
        last_result = str(tool_results[-1].get("result")) if tool_results else None

        return {
            "success": True,
            "response": final_state.get("final_response", ""),
            "scope": extracted_scope,
            "retrieved_context": retrieved_context,
            "firewall_result": firewall_result,
            "action_guard_result": action_guard_result,
            "tool_used": last_tool,
            "tool_result": last_result,
            "tool_calls": tool_calls,
            "tool_results": tool_results,
        }
