"""
LangGraph node implementations for PromptWall Stage 8 Agent (Action Guard).

Workflow:
  1. scope_extraction_node  — extract user intent & scope (Stage 7)
  2. rag_retrieval_node     — retrieve context from RAG
  3. content_firewall_node  — inspect, detect, classify, and sanitize retrieved context (Stage 6)
  4. agent_reasoning_node   — analyze safe context & tool history, decide tool or final response
  5. action_guard_node      — evaluate proposed tool against scope (Stage 8)
  6. tool_execution_node    — execute mock tools and sanitize tool results via firewall
  7. response_builder_node  — construct final response
"""

import os
import re
from typing import Any, Dict, List, Optional

from agent.prompts import SYSTEM_PROMPT, format_context_prompt
from agent.state import AgentState
from security.content_firewall import content_firewall
from tools import AVAILABLE_TOOLS

from scope import scope_extractor
from guard import action_guard


_rag_pipeline = None


def _get_rag():
    global _rag_pipeline
    if _rag_pipeline is None:
        from rag.retriever import RAGPipeline
        data_dir = os.path.join(os.path.dirname(__file__), "..", "data")
        _rag_pipeline = RAGPipeline(data_dir)
        _rag_pipeline.initialize()
    return _rag_pipeline


# ---------------------------------------------------------------------------
# Node 0 — Scope Extractor (Stage 7)
# ---------------------------------------------------------------------------
def scope_extraction_node(state: AgentState) -> Dict[str, Any]:
    """
    Stage 7 Scope Extractor node.
    Extracts intended scope strictly from the trusted user request.
    Does NOT evaluate or enforce Action Guard permissions (Stage 8).
    """
    user_request = state["user_request"]
    extracted_scope = scope_extractor.extract(user_request)
    return {
        "scope": extracted_scope.model_dump(),
    }


# ---------------------------------------------------------------------------
# Node 1 — RAG Retrieval
# ---------------------------------------------------------------------------
def rag_retrieval_node(state: AgentState) -> Dict[str, Any]:
    """Retrieve relevant document chunks using the RAG pipeline."""
    rag = _get_rag()
    query = state["user_request"]
    results = rag.retrieve(query, top_k=3)

    return {
        "retrieved_context": results,
        "tool_calls": state.get("tool_calls", []),
        "tool_results": state.get("tool_results", []),
        "step_count": state.get("step_count", 0),
    }


# ---------------------------------------------------------------------------
# Node 2 — Content Firewall Inspection & Sanitization (Stage 6)
# ---------------------------------------------------------------------------
def content_firewall_node(state: AgentState) -> Dict[str, Any]:
    """
    Stage 6 Content Firewall node.
    Inspects, sanitizes, and quarantines prompt injections in retrieved RAG context.
    Constructs safe messages context using trust boundary delimiters.
    """
    raw_context = state.get("retrieved_context", [])
    query = state["user_request"]

    sanitized_context, firewall_summary = content_firewall.inspect_rag_results(raw_context)

    formatted_user_msg = format_context_prompt(query, sanitized_context)

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": formatted_user_msg},
    ]

    return {
        "retrieved_context": sanitized_context,
        "firewall_result": firewall_summary,
        "messages": messages,
    }


# ---------------------------------------------------------------------------
# Node 3 — Agent Reasoning & Tool Decision
# ---------------------------------------------------------------------------
def agent_reasoning_node(state: AgentState) -> Dict[str, Any]:
    """
    Reason over request, sanitized safe context, and executed tool results.
    Decide whether to invoke another tool or output the final response.
    """
    user_request = state["user_request"]
    context_chunks = state.get("retrieved_context", [])
    executed_tool_names = [call.get("tool") for call in state.get("tool_calls", [])]
    step_count = state.get("step_count", 0)

    # Max step limit to prevent infinite loops
    if step_count >= 5:
        response = _synthesize_final_response(
            user_request, context_chunks, state.get("tool_results", []),
            state.get("firewall_result"), state.get("action_guard_result")
        )
        return {"proposed_tool": None, "tool_arguments": None, "final_response": response}

    # Decide next tool call
    executed_tool_calls = state.get("tool_calls", [])
    tool_decision = _decide_tool(user_request, context_chunks, executed_tool_names, executed_tool_calls)

    if tool_decision:
        tool_name, tool_args = tool_decision
        return {
            "proposed_tool": tool_name,
            "tool_arguments": tool_args,
        }

    # No further tools needed -> synthesize final response
    response = _synthesize_final_response(
        user_request, context_chunks, state.get("tool_results", []),
        state.get("firewall_result"), state.get("action_guard_result")
    )
    return {
        "proposed_tool": None,
        "tool_arguments": None,
        "final_response": response,
    }


def _decide_tool(
    user_request: str,
    context_chunks: List[Dict[str, Any]],
    executed_tools: List[str],
    executed_tool_calls: List[Dict[str, Any]] = None
) -> Optional[tuple]:
    """
    Determine if a tool call is needed based on prompt intent and execution history.
    Fully dynamic & generalized — works with arbitrary files, search terms, recipients, and datasets.
    """
    req_lower = user_request.lower()
    context_text = "\n".join(c.get("text", "") for c in context_chunks).lower()
    combined_text = req_lower + " " + context_text
    executed_tool_calls = executed_tool_calls or []

    # 1. read_file tool check: search for files mentioned in prompt or context
    file_matches = re.findall(r"[\w\-.+]+\.(?:txt|pdf|csv|md|json|log|docx)", combined_text, re.IGNORECASE)
    if file_matches:
        for target_file in file_matches:
            already_read = any(
                call.get("tool") == "read_file" and call.get("arguments", {}).get("path", "").lower() == target_file.lower()
                for call in executed_tool_calls
            )
            if not already_read:
                return ("read_file", {"path": target_file})

    if "read_file" not in executed_tools:
        if any(kw in req_lower for kw in ["read", "open", "file", "document", "inspect", "analyze", "compare"]):
            # Try finding any file in sandbox directory dynamically
            sandbox_dir = os.path.realpath(
                os.path.join(os.path.dirname(__file__), "..", "data", "mock_files")
            )
            if os.path.exists(sandbox_dir):
                available_files = [f for f in os.listdir(sandbox_dir) if os.path.isfile(os.path.join(sandbox_dir, f))]
                unread_files = [
                    f for f in available_files
                    if not any(
                        call.get("tool") == "read_file" and call.get("arguments", {}).get("path", "").lower() == f.lower()
                        for call in executed_tool_calls
                    )
                ]
                if unread_files:
                    return ("read_file", {"path": unread_files[0]})

    # 2. search_web tool check
    if "search_web" not in executed_tools:
        if any(kw in req_lower for kw in ["search", "web", "online", "internet", "market", "standard", "sla", "lookup", "find"]):
            return ("search_web", {"query": user_request})

    # 3. send_email tool check
    if "send_email" not in executed_tools:
        if any(kw in req_lower for kw in ["send", "email", "mail", "notify"]):
            email_match = re.search(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", combined_text)
            recipient = email_match.group(0) if email_match else "authorized_user@example.com"
            return (
                "send_email",
                {
                    "recipient": recipient,
                    "subject": f"Summary: {user_request[:50]}",
                    "body": f"Automated summary response for: {user_request}",
                    "attachment": "document_summary.pdf",
                },
            )

    # 4. write_record tool check
    if "write_record" not in executed_tools:
        if any(kw in req_lower for kw in ["store", "save", "record", "log", "db", "database", "write"]):
            return (
                "write_record",
                {
                    "record_type": "user_task_record",
                    "data": {
                        "user_request": user_request,
                        "retrieved_chunk_count": len(context_chunks),
                        "status": "COMPLETED",
                    },
                },
            )

    return None


# ---------------------------------------------------------------------------
# Node 4 — Action Guard (Stage 8)
# ---------------------------------------------------------------------------
def action_guard_node(state: AgentState) -> Dict[str, Any]:
    """
    Stage 8 Action Guard node.
    Evaluates the proposed tool call against the extracted user scope.
    Decisions: ALLOW → proceed to tool_execution, BLOCK → skip tool, ASK_HUMAN → flag for review.
    """
    proposed_tool = state.get("proposed_tool")
    tool_arguments = state.get("tool_arguments") or {}
    scope = state.get("scope")
    tool_history = state.get("tool_calls", [])

    # If no tool proposed, pass through
    if not proposed_tool:
        return {
            "action_guard_result": None,
        }

    # Evaluate against scope using Action Guard engine
    decision = action_guard.evaluate(
        proposed_tool=proposed_tool,
        tool_arguments=tool_arguments,
        scope=scope,
        tool_history=tool_history,
    )

    guard_result = decision.model_dump()

    # If BLOCKED, clear proposed_tool so tool_execution is skipped
    if decision.decision == "BLOCK":
        # Record the blocked attempt in tool history
        tool_calls = list(state.get("tool_calls", []))
        tool_results = list(state.get("tool_results", []))
        tool_calls.append({"tool": proposed_tool, "arguments": tool_arguments, "blocked": True})
        tool_results.append({
            "tool": proposed_tool,
            "result": {
                "success": False,
                "error": "ACTION_GUARD_BLOCKED",
                "message": f"Action Guard blocked: {decision.reason}",
                "risk_level": decision.risk_level,
                "violated_rules": decision.violated_rules,
            },
        })
        return {
            "action_guard_result": guard_result,
            "proposed_tool": None,
            "tool_arguments": None,
            "tool_calls": tool_calls,
            "tool_results": tool_results,
            "step_count": state.get("step_count", 0) + 1,
        }

    # If ASK_HUMAN, still allow through in sandbox mode but flag it
    # (In production, this would pause for human approval)
    if decision.decision == "ASK_HUMAN":
        guard_result["sandbox_note"] = "In production, this would pause for human approval. Sandbox mode: proceeding with flag."

    return {
        "action_guard_result": guard_result,
    }


# ---------------------------------------------------------------------------
# Node 5 — Tool Execution
# ---------------------------------------------------------------------------
def tool_execution_node(state: AgentState) -> Dict[str, Any]:
    """Execute the selected mock tool, run firewall on tool result, and record state."""
    proposed_tool = state.get("proposed_tool")
    tool_arguments = state.get("tool_arguments") or {}

    if not proposed_tool or proposed_tool not in AVAILABLE_TOOLS:
        return {}

    tool_fn = AVAILABLE_TOOLS[proposed_tool]
    try:
        raw_result = tool_fn(**tool_arguments)
        # Inspect and sanitize untrusted tool output
        sanitized_result, tool_inspection = content_firewall.inspect_tool_result(
            proposed_tool, raw_result
        )
    except Exception as exc:
        sanitized_result = {"success": False, "error": "TOOL_EXECUTION_ERROR", "message": str(exc)}

    tool_calls = list(state.get("tool_calls", []))
    tool_results = list(state.get("tool_results", []))

    tool_calls.append({"tool": proposed_tool, "arguments": tool_arguments})
    tool_results.append({"tool": proposed_tool, "result": sanitized_result})

    return {
        "tool_result": sanitized_result,
        "tool_calls": tool_calls,
        "tool_results": tool_results,
        "step_count": state.get("step_count", 0) + 1,
        "proposed_tool": None,
        "tool_arguments": None,
    }


# ---------------------------------------------------------------------------
# Node 6 — Response Builder
# ---------------------------------------------------------------------------
def response_builder_node(state: AgentState) -> Dict[str, Any]:
    """Format final response object."""
    response = state.get("final_response") or "Agent completed workflow."
    return {"final_response": response}


def _synthesize_final_response(
    user_request: str,
    context_chunks: List[Dict[str, Any]],
    tool_results: List[Dict[str, Any]],
    firewall_result: Optional[Dict[str, Any]] = None,
    action_guard_result: Optional[Dict[str, Any]] = None,
) -> str:
    """Synthesize structured final text response incorporating firewall status, action guard, RAG, and tool results."""
    lines = []

    # Section 1: Content Firewall Security Status Banner if flagged/quarantined
    if firewall_result and firewall_result.get("status") == "QUARANTINED":
        lines.append("🛡️ [CONTENT FIREWALL: SANITIZED & PASSED]")
        lines.append(f"Status: SANITIZED | Classification: {firewall_result.get('classification')} (Confidence: {firewall_result.get('confidence', 0.0):.2f})")
        lines.append(f"Reason: {firewall_result.get('reason')}")
        lines.append("Action: Prompt injection instructions were neutralized ([QUARANTINED]). Legitimate document content was preserved and safely passed to the agent.")
        lines.append("")

    # Section 1b: Action Guard Status Banner
    if action_guard_result and action_guard_result.get("decision") != "ALLOW":
        decision = action_guard_result.get("decision", "UNKNOWN")
        tool = action_guard_result.get("tool", "unknown")
        risk = action_guard_result.get("risk_level", "UNKNOWN")
        reason = action_guard_result.get("reason", "")
        emoji = "🚫" if decision == "BLOCK" else "⚠️"
        lines.append(f"{emoji} [ACTION GUARD: {decision}]")
        lines.append(f"Tool: {tool} | Risk: {risk}")
        lines.append(f"Reason: {reason}")
        lines.append("")

    # Section 2: Tool Execution Summary
    if tool_results:
        lines.append("### Executed Tool Results:")
        for res_entry in tool_results:
            tool_name = res_entry.get("tool")
            result = res_entry.get("result", {})
            if isinstance(result, dict):
                if result.get("error") == "ACTION_GUARD_BLOCKED":
                    lines.append(f"• Tool `{tool_name}` 🚫 BLOCKED by Action Guard: {result.get('message', '')}")
                elif result.get("success"):
                    if tool_name == "read_file":
                        content_len = len(result.get("content", ""))
                        file_path = result.get("path", "file")
                        lines.append(f"• Tool `{tool_name}` executed: Successfully read file '{file_path}' ({content_len} bytes).")
                    elif tool_name == "search_web":
                        count = len(result.get("results", []))
                        mock_label = " [MOCK]" if result.get("mock") else ""
                        lines.append(f"• Tool `{tool_name}` executed{mock_label}: Web search completed ({count} results found).")
                    elif tool_name == "send_email":
                        mock_label = " [MOCK]" if result.get("mock") else ""
                        lines.append(f"• Tool `{tool_name}` executed{mock_label}: Email sent to {result.get('details', {}).get('recipient', result.get('recipient', 'unknown'))}.")
                    elif tool_name == "write_record":
                        mock_label = " [MOCK]" if result.get("mock") else ""
                        lines.append(f"• Tool `{tool_name}` executed{mock_label}: Database record written successfully.")
                    else:
                        msg = result.get("message") or f"Execution succeeded."
                        lines.append(f"• Tool `{tool_name}` executed: {msg}")
                else:
                    err_msg = result.get("message") or result.get("error") or "Execution failed."
                    lines.append(f"• Tool `{tool_name}` executed: {err_msg}")
            else:
                lines.append(f"• Tool `{tool_name}` executed: {result}")
        lines.append("")

    # Section 3: Synthesis Analysis
    lines.append("### Synthesis Analysis:")

    file_contents = [
        res.get("result", {}).get("content")
        for res in tool_results
        if res.get("tool") == "read_file" and res.get("result", {}).get("success")
    ]
    if file_contents:
        lines.append("File Content Retrieved:")
        for content in file_contents:
            lines.append(f"```\n{content}\n```")
        lines.append("")

    search_results = [
        res.get("result", {}).get("results")
        for res in tool_results
        if res.get("tool") == "search_web" and res.get("result", {}).get("success")
    ]
    if search_results and search_results[0]:
        lines.append("Web Search Results:")
        for item in search_results[0]:
            lines.append(f"  - [{item.get('title')}] ({item.get('source')}): {item.get('snippet')}")
        lines.append("")

    delivery_times: Dict[str, str] = {}
    prices: Dict[str, str] = {}

    for chunk in context_chunks:
        text = chunk.get("text", "")
        source = chunk.get("source_id", "")
        for line in text.split("\n"):
            line_str = line.strip()
            if "delivery time:" in line_str.lower():
                delivery_times[source] = line_str
            elif "unit price:" in line_str.lower():
                prices[source] = line_str

    req_lower = user_request.lower()
    if delivery_times and ("delivery" in req_lower or "shortest" in req_lower or "fastest" in req_lower):
        lines.append("Delivery Times from Vendor Quotations:")
        for src, val in sorted(delivery_times.items()):
            lines.append(f"  • {src}: {val.split(':', 1)[1].strip()}")
    elif prices and ("price" in req_lower or "cost" in req_lower):
        lines.append("Unit Prices from Vendor Quotations:")
        for src, val in sorted(prices.items()):
            lines.append(f"  • {src}: {val.split(':', 1)[1].strip()}")
    elif not file_contents and not search_results:
        if context_chunks:
            lines.append(f"Retrieved {len(context_chunks)} relevant vendor quotation chunk(s) from document corpus.")
        else:
            lines.append("The requested information is not available in the retrieved document corpus.")

    return "\n".join(lines)
