"""
Pydantic models for Stage 7 — Scope Extractor.
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class TaskScope(BaseModel):
    """
    Structured representation of the requested user scope.
    Determined strictly from trusted user requests.
    """
    intent: str = Field(description="Primary user intent (e.g. vendor_comparison, read_document, summarize, send_email, write_record)")
    requested_actions: List[str] = Field(default_factory=list, description="Explicitly requested action identifiers")
    inferred_actions: List[str] = Field(default_factory=list, description="Actions inferred as necessary to fulfill explicit intent")
    requested_resources: List[str] = Field(default_factory=list, description="Target filenames or resources explicitly named in user prompt")
    requested_targets: List[str] = Field(default_factory=list, description="Target recipients or destinations explicitly named in user prompt")
    requested_outputs: List[str] = Field(default_factory=list, description="Requested output formats or records")
    constraints: List[str] = Field(default_factory=list, description="Explicit restrictions or limitations stated by user (e.g., no_modification)")
    explicit_authorizations: List[str] = Field(default_factory=list, description="Explicit user permissions granted in prompt")
    is_trusted_user_scope: bool = Field(default=True, description="Always True since derived strictly from user request, never untrusted content")
    scope_confidence: float = Field(default=1.0, description="Confidence score between 0.0 and 1.0")
    raw_user_request: str = Field(default="", description="The exact user prompt evaluated")


class ScopeExtractRequest(BaseModel):
    message: str


class ScopeExtractResponse(BaseModel):
    success: bool
    scope: TaskScope
